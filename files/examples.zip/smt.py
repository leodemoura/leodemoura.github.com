from z3 import *

a    = Array('a', IntSort(), IntSort())
b, c = Ints('b c')
f    = Function('f', IntSort(), IntSort())

solve(b + 2 == c, f(Select(Store(a, b, 3), c - 2)) != f(c - b + 1))

# Using a SMT solver object
s = Solver()
s.add(b + 2 == c, f(Select(Store(a, b, 3), c - 2)) != f(c - b + 1))
print s.check()

# Using syntax sugar

solve(b + 2 == c, f(Store(a, b, 3)[c - 2]) != f(c - b + 1))


