from z3 import *

# D[i][j] contains the amount of time needed by job i on machine j
D = [[2, 1],
     [3, 1],
     [2, 3]]
Max = 8

print D

num_jobs     = len(D)
if num_jobs > 0:
    num_machines = len(D[0])
    # Check if the size of all rows is the same
    for i in range(num_jobs):
        assert len(D[i]) == num_machines

# Create an integer variable for every cell D[i][j]
T = [ [ Int('t_%d_%d' % (i+1, j+1)) for j in range(num_machines) ] for i in range(num_jobs) ]

print T

# The starting time of the first task of each job is >= 0
C1 = And([ T[i][0] >= 0 for i in range(num_jobs) ])
# The last taks must finish before Max
C2 = And([ T[i][num_machines - 1] + D[i][num_machines - 1] <= Max for i in range(num_jobs) ])
# Task j+1 must start after end of task j
C3 = And([ And([ T[i][j+1] >= T[i][j] + D[i][j] for j in range(num_machines - 1)]) for i in range(num_jobs) ])
# Tasks from different jobs cannot be running in the same machine at the same time
C4_lst = []
for i1 in range(num_jobs):
    for i2 in range(i1):
        for j in range(num_machines):
            C4_lst.append(Or(T[i1][j] >= T[i2][j] + D[i2][j],
                             T[i2][j] >= T[i1][j] + D[i1][j]))
C4 = And(C4_lst)

print C1
print C2
print C3
print C4
solve(C1, C2, C3, C4)


