from z3 import *

# Auxiliary function for iterating over all Boolean tuples/lists of size n.
def next(A):
    n = len(A)
    for i in range(n):
        if not A[i]:
            A[i] = True
            return True
        else:
            A[i] = False
    return False

# Example
A = [False, False, False]
cont = True
while cont:
    print A
    cont = next(A)

# Return a if pos == True, and Not(a) if pos == False
def mk_literal(pos, a):
    if pos:
        return a
    else:
        return Not(a)

# Return True if minterm implies e.
def check(minterm, e):
    s = Solver()
    s.add(minterm)
    s.add(Not(e))
    return s.check() == unsat

def implies_F(F, e):
    n = len(F)
    A = [ False for i in range(n) ]
    B = [ FreshBool() for i in range(n) ]
    R = []
    cont = True

    while cont:
        minterm = And([ mk_literal(A[i], F[i]) for i in range(n) ])
        if check(minterm, e):
            R.append(And([ mk_literal(A[i], B[i]) for i in range(n) ]))
        cont = next(A)

    if len(R) == 0:
        return (B, BoolVal(True))
    elif len(R) == 1:
        return B, R[0]
    else:
        return B, Or(R)

def impliedBy_F(F, e):
    B, R = implies_F(F, Not(e))
    return B, Not(R)

x, y = Ints('x y')
print implies_F([x < y, x == 2], y > 1)
