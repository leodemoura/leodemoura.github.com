from z3 import *

set_option(auto_config=True)
set_option(verbose=10)

N = 8

OP_BVADD  = 0
OP_BVAND  = 1
OP_BVNOT  = 2
OP_PROJ   = 3

def some_app(op, x1, x2):
    return If(op == OP_BVADD, x1 + x2,
           If(op == OP_BVAND, x1 & x2,
           If(op == OP_BVNOT, ~x1,
              x1)))

def _some_arg(sel, idx, args):
    if idx == len(args) - 1:
        return args[idx]
    else:
        return If(sel == idx, args[idx], _some_arg(sel, idx+1, args))

def some_arg(sel, *args):
    assert len(args) > 0
    return _some_arg(sel, 0, args)

BOP_AND   = 0
BOP_OR    = 1
BOP_NOT   = 2

def some_bool_app(op, x1, x2):
    return If(op == BOP_AND,  And(x1, x2),
           If(op == BOP_OR,   Or(x1, x2),
              Not(x1)))

c1                             = BitVec('c1', N)
op1, op2, op3, op4, op5, op6   = BitVecs('op1 op2 op3 op4 op5 op6', N)
s1, s2, s3, s4, s5, s6, s7, s8 = BitVecs('s1 s2 s3 s4 s5 s6 s7 s8', N) 
b1, b2                         = Bools('b1 b2')
bop                            = BitVec('bop', N)

def is_power_of_2(x):
    if x == 1:
        return True
    elif x == 0:
        return False
    if x % 2 == 1:
        return False
    else:
        return is_power_of_2(x / 2)

def PwCnstr(x):
    app1 = some_app(op1, some_arg(s1, x, c1), some_arg(s2, x, c1))
    app2 = some_app(op2, some_arg(s3, x, c1), some_arg(s4, x, c1))
    exp1 = some_app(op3, app1, app2)
    C1   = If(b1, exp1 != 0, exp1 == 0)

    app1 = some_app(op4, some_arg(s4, x, c1), some_arg(s5, x, c1))
    app2 = some_app(op5, some_arg(s6, x, c1), some_arg(s7, x, c1))
    exp2 = some_app(op6, app1, app2)
    C2   = If(b2, exp2 != 0, exp2 == 0)

    C    = some_bool_app(bop, C1, C2)
    
    if is_power_of_2(x):
        return C
    else:
        return Not(C)

s = Tactic('qfbv').solver()
for i in range(2**N - 1):
    s.add(PwCnstr(i))

def decode_arg(s, *args):
    s = s.as_long()
    if s >= len(args):
        s = len(args) - 1
    return args[s]

def decode_app(op, x1, x2):
    op = op.as_long()
    if op == OP_BVADD:
        return x1 + x2
    elif op == OP_BVAND:
        return x1 & x2
    elif op == OP_BVNOT:
        return ~x1
    elif op == OP_PROJ:
        return x1
    else:
        assert false

def decode_atom(b, a):
    if is_true(b):
        return a != 0
    else:
        return a == 0

def decode_bool_app(bop, x1, x2):
    bop = bop.as_long()
    if bop == 0:
        return And(x1, x2)
    elif bop == 1:
        return Or(x1, x2)
    else:
        return Not(x1)

def is_pw2(x):
    return Or([ x == 2**i for i in range(N) ])

def decode(m):
    x = BitVec('x', N)

    app1 = decode_app(m[op1], decode_arg(m[s1], x, m[c1]), decode_arg(m[s2], x, m[c1]))
    app2 = decode_app(m[op2], decode_arg(m[s3], x, m[c1]), decode_arg(m[s4], x, m[c1]))
    exp1 = decode_app(m[op3], app1, app2)
    C1   = decode_atom(m[b1], exp1)
    
    app1 = decode_app(m[op4], decode_arg(m[s4], x, m[c1]), decode_arg(m[s5], x, m[c1]))
    app2 = decode_app(m[op5], decode_arg(m[s6], x, m[c1]), decode_arg(m[s7], x, m[c1]))
    exp2 = decode_app(m[op6], app1, app2)
    C2   = decode_atom(m[b2], exp2)
    R    = decode_bool_app(m[bop], C1, C2)
    print R
    print simplify(R)
    prove(R == is_pw2(x))

def block_model(s, m):
    B = Or([ d() != m[d] for d in m ])
    print B
    s.add(B)

s.check()
print "Solution: "
m = s.model()
decode(m)
block_model(s, m)
s.check()
print "Solution: "
m = s.model()
decode(m)
block_model(s, m)
s.check()
print "Solution: "
m = s.model()
decode(m)
