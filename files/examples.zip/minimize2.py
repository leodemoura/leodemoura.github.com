from z3 import *

x, y, z = Ints('x y z')
s = Solver()
s.add(x >= -1000, y >= -1000, z >= -1000, x != 0, x + y + z >= 10, x >= 2*y)
print s
print s.check()
print s.model()

def select_big_var(m, xs, Min, Max):
    for x in xs:
        assert is_int(x)
        if m[x].as_long() < Min or m[x].as_long() > Max:
            return x
    return None

def try_to_reduce(s, x, Min, Max):
    s.push()
    s.add(x <= Max)
    s.add(Min <= x)
    if s.check() == sat:
        return True
    else:
        s.pop()
        return False

def find_small(s, xs, Min, Max):
    if s.check() != sat:
        return None
    m = s.model()
    while True:
        x = select_big_var(m, xs, Min, Max)
        if x == None:
            return m
        if try_to_reduce(s, x, Min, Max):
            m = s.model()
        xs.remove(x)
            
print find_small(s, [x, y, z], 0, 100)

