from z3 import *

a, b = Ints('a b')
F = Implies(And(a <= 1, a <= b), b != 0)

print F
prove(F)

F = Implies(And(1 <= a, a <= b), b != 0)

print F
prove(F)


