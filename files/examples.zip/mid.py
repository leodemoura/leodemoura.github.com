from z3 import *

low, high, mid, length = BitVecs('low high mid length', 32)

assumption = And(0 <= low, low < high, high < length, mid == (low + high)/2)
conjecture = And(0 <= mid, mid < length)

prove(Implies(assumption, conjecture))

assumption = And(0 <= low, low < high, high < length, mid == low + (high - low)/2)
conjecture = And(0 <= mid, mid < length)

prove(Implies(assumption, conjecture))

assumption = And(ULE(0, low), ULT(low, high), ULT(high, length), mid == UDiv(low + high, 2))
conjecture = And(ULE(0, mid), ULT(mid, length))

prove(Implies(assumption, conjecture))

assumption = And(ULE(0, low), ULT(low, high), ULT(high, length), mid == UDiv(low + high, 2))
conjecture = And(ULE(low, mid), ULT(mid, length))

prove(Implies(assumption, conjecture))

assumption = And(ULE(0, low), ULT(low, high), ULT(high, length), mid == low + UDiv(high - low, 2))
conjecture = And(ULE(low, mid), ULT(mid, length))

prove(Implies(assumption, conjecture))


