from z3 import *

d, a, t, v_i, v_f = Reals('d a t v_i v_f')

equations = [
   d == v_i * t + (a*t**2)/2,
   v_f == v_i + a*t,
]

# Given v_f, t and a, find d
problem = [
    v_f == 5.0,
    t   == 4.10,
    a   == 6
]

solve(equations + problem)

# Display rationals in decimal notation
set_option(rational_to_decimal=True)

solve(equations + problem)

prove(Implies(And(equations), d == v_f * t - (a*t**2)/2))
prove(Implies(And(equations), d == v_f * t + (a*t**2)/2))

prove(Implies(And(equations), v_f**2 == v_i**2 + 2*a*d))

prove(Implies(And(equations), v_f**2 == v_i**2 + 3*a*d))

