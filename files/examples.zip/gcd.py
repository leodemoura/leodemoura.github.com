from z3 import *

y0, y1 = BitVecs('y0 y1', 32)
# syntax sugar for
#  y0 = BitVec('y0', 32)
#  y1 = BitVec('y1', 32)
x0, x1 = BitVecs('x0 x1', 32)
m0, m1 = BitVecs('m0 m1', 32)

solve(
    y0 > 0,
    m0 == x0 % y0,
    m0 != 0,
    x1 == y0,
    y1 == m0,
    m1 == x1 % y1,
    m1 == 0
    )


   
