describe_tactics()
