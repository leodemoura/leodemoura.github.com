x = Int('x')
print (x + 1).hash()
print (1 + x).hash()
print x.sort().hash()
