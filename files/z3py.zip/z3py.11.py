x = Real('x')
s = Solver()
s.add(2**x == 3)
print s.check()
