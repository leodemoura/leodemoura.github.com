x = Real('x')
solve(x > 4, x < 0)
